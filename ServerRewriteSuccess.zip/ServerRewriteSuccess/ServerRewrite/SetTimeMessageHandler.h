#ifndef _SETTIMEMESSAGEHANDLER_H_
#define _SETTIMEMESSAGEHANDLER_H_

#include "Message.h"
#include "User.h"
#include "SystemHead.h"
#include "Translation.h"


class SetTimeMessageHandler
{

private:
	//static priority_queue<Message> SetTimeMessageQueue;
	static Message SetTimeMessageQueue[1000];
	static CRITICAL_SECTION selfCritical;
	static int SetTimeMessageQueueTop;
	static DWORD WINAPI CheckTime(LPVOID arg)//��ʱ���Ų�����ҪCheck
	{
		while (1)
		{
			time_t nowTime;//δ��ʼ��
			if (SetTimeMessageQueueTop!=0)
			{
				EnterCriticalSection(&selfCritical);		
				Message	headMessage=SetTimeMessageQueue[SetTimeMessageQueueTop];			
				LeaveCriticalSection(&selfCritical);
				//ȡ����ʱ���Ŷ��ס�

				if (headMessage.setTime==nowTime)
				{
					headMessage.IssetTime=false;
					EnterCriticalSection(&critical);
					msgToBeDealed[rear]=TranslationHandler::messageToString(headMessage);
					rear++;
					LeaveCriticalSection(&critical);
					//���ӵ���������

					EnterCriticalSection(&selfCritical);
					SetTimeMessageQueueTop--;
					LeaveCriticalSection(&selfCritical);
					//�޸Ķ�ʱ���Ŷ���
				}
			}
			Sleep(10);
		}
	}

	static int cmp(const void *a,const void *b)
	{
		Message *a1=(Message *)a;
		Message *b1=(Message *)b;
		return a1->setTime-b1->setTime;
	}
public:
	static void startWorking()
	{
		Sleep(5);
		InitializeCriticalSection(&selfCritical);
		HANDLE Handler=CreateThread(NULL,0,CheckTime,NULL,0,NULL);//Ӧ���ǲ����������
		printf("��ʱ���Ŵ���ģ�鿪ʼ���У�\n");
	}


	static void addMessage(Message o)
	{
		EnterCriticalSection(&selfCritical);
		SetTimeMessageQueue[SetTimeMessageQueueTop]=o;
		SetTimeMessageQueueTop++;
		qsort(SetTimeMessageQueue,SetTimeMessageQueueTop,sizeof(Message),cmp);
		LeaveCriticalSection(&selfCritical);
	}
};
Message SetTimeMessageHandler::SetTimeMessageQueue[1000];
CRITICAL_SECTION SetTimeMessageHandler::selfCritical;
int SetTimeMessageHandler::SetTimeMessageQueueTop=0;











#endif