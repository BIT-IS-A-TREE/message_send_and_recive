#ifndef _COMMUNICATIONHANDLER_H_
#define _COMMUNICATIONHANDLER_H_
#include "User.h"
#include "Message.h"
#include "SystemHead.h"

class CommunicationHandler
{

private:
	CRITICAL_SECTION selfCritical;
	bool endFlag;
	static void Sending(void *arg)
	{
		CommunicationHandler *This=(CommunicationHandler *)arg;
		printf("ͬ�ͻ��ˣ�%s�������ݵ�ͨ���ѽ���\n",inet_ntoa(This->addrClient.sin_addr));
		This->msgToSend=0;
	//	memset(This->msgToSend,0,sizeof(This->msgToSend));
	//	strcpy(This->msgToSend,"������ѣ�\n");

		while (1)//����ط�����Ҫ��critical
		{
			EnterCriticalSection(&This->selfCritical);
			if (This->msgToSend!=0)
			{
				printf("*********");
				char temp[100];
				strcpy(temp,"dsaf");
				send(This->sockClient,temp,strlen(temp)+1,0);
				printf("��ͻ���%s�������ݣ�%s\n",inet_ntoa(This->addrClient.sin_addr),This->msgToSend);
				//memset(This->msgToSend,0,sizeof(This->msgToSend));
				This->msgToSend=0;
			}
			LeaveCriticalSection(&This->selfCritical);
			Sleep(10);
		}

	//	Sleep(10);
	//	shutdown(This->sockClient,1);

		printf("�����߳��˳���\n");
	}
	static void Recieving(void * arg)
	{
		CommunicationHandler *This=(CommunicationHandler *)arg;
		printf("���ڽ��տͻ��ˣ�%s���ݵ�ͨ���ѽ���\n",inet_ntoa(This->addrClient.sin_addr));//��ӡ��ʽ��IP��ַ,����ط�Ҫд��friend
		while (!This->endFlag)
		{
			char buf[10000]; 
			recv(This->sockClient,buf,10000,0);
			printf("�ӿͻ���%s���յ����ݣ�%s\n",inet_ntoa(This->addrClient.sin_addr),buf);
			EnterCriticalSection(&critical);//ȫ��critical
			msgToBeDealed[rear]=string(buf);
			rear++;
			LeaveCriticalSection(&critical);
			Sleep(10);
		}

		
		//shutdown(This->sockClient,0);

		printf("�����߳��˳���\n");
	}
	static void Connecting(void *arg)
	{
		


		CommunicationHandler * This=(CommunicationHandler *)arg;

		This->endFlag=false;
		//memset(This->msgToSend,0,sizeof(This->msgToSend));
		InitializeCriticalSection(&This->selfCritical);




		printf("�ͻ���%s��������\n",inet_ntoa(This->addrClient.sin_addr));
		This->startRecieving();
		This->startSending();
		while (!This->endFlag)
		{
			;
		}
		Sleep(1000);
		
	//	shutdown(This->sockClient,3);
		closesocket(This->sockClient);//����ط�close��������ٿ��ǿ��ǡ�
		
		printf("���߳��˳���\n");
		Sleep(1000);
	}
	int startSending()
	{
		return _beginthread(Sending,0,(void *)this);
	}
	int startRecieving()
	{
		return _beginthread(Recieving,0,(void *)this);
	}
	
public:
	SOCKET sockClient,sockServer;
	//char msgToSend[10000];
	int msgToSend;
	SOCKADDR_IN addrClient;
	CommunicationHandler(SOCKET serSocket,SOCKET client,SOCKADDR_IN addr);
	
	void sendInformation(string o)
	{
		EnterCriticalSection(&this->selfCritical);
	//	msgToSend=o;
		LeaveCriticalSection(&this->selfCritical);
	}

	void sendInformation(Message o)
	{
		EnterCriticalSection(&this->selfCritical);
	//	strcpy(this->msgToSend,o.content);
 	//	this->msgToSend=string(o.content);
		this->msgToSend=1;
		LeaveCriticalSection(&this->selfCritical);
	}

	void sendInformation(char * o)
	{
		//string temp(o);
		EnterCriticalSection(&this->selfCritical);
	//	strcpy(msgToSend,o);
		LeaveCriticalSection(&this->selfCritical);
	}
	void endSocket()
	{
		endFlag=true;
	}

	int startConnecting()
	{
		return _beginthread(Connecting,0,(void *)this);
	}
	
	
};



CommunicationHandler::CommunicationHandler(SOCKET serSocket,SOCKET client,SOCKADDR_IN addr)//��Ҫ����һ�Ρ�
{
	this->endFlag=false;
	this->addrClient=addr;
	this->sockClient=client;
	this->sockServer=serSocket;
}


#endif