#ifndef _USER_H_
#define _USER_H_


class User{
public:
	char ip[50];
	char username[50];
	char password[50];
	
};

#endif