#ifndef _TRANSLATION_H_
#define _TRANSLATION_H_
#include "SystemHead.h"
#include "Message.h"
#include "User.h"
class TranslationHandler
{
public:
	static string messageToString(Message o)
	{
		string a;
		return a;
	}
	static Message stringToMessage(string &o)
	{
		Message a;
		return a;
		
	}
	
};


#endif